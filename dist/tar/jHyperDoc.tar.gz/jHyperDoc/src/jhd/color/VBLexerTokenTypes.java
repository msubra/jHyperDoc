// $ANTLR 2.7.2a2 (20020112-1): "vb.g" -> "VBLexer.java"$

package jhd.color;

public interface VBLexerTokenTypes {
	int EOF = 1;
	int NULL_TREE_LOOKAHEAD = 3;
	int HEXA = 4;
	int BRACKETS = 5;
	int OPERATORS = 6;
	int WS = 7;
	int SL_COMMENT = 8;
	int STRING_LITERAL = 9;
	int IDENT = 10;
	int NUM_INT = 11;
	int HEX_DIGIT = 12;
	int VOCAB = 13;
	int REAL = 14;
	int INT = 15;
	int DIGIT = 16;
	int EXPONENT = 17;
}
