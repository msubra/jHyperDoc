==========================================================================	
			jHyperDoc - Source code to HTML File Converter
==========================================================================
	jHyperDoc by created by Maheshwaran.S of Sona College of Technology, B.E III Year CSE. jHyperDoc converts the source codes into the HTML File format. jCalculus is writting in Java using Antlr( http://www.antlr.org).

	List of SOurce Code that jHyperDoc can convert.

		Java 
		C 
		CPP 
		C++ 
		CXX 
		CX 
		H 
		HXX 
		HPP 
		TXT ( currently for VB 5, VB 6) 
		VB - VB.NET 
		CS - C# 
		PY - Python 


email: smahesh_monu@rediffmail.com or mahesh_cse@ieee.org
web: http://microprogrammers.150m.com

�

Source Package:
---------------
	The jCalculus source is provided under the GNU public license. Read the license for more details.

	/src 	---> source files
	/lib 	---> library files
	/keywords --> keywords files. don't delete thosefiles
	/docs 	---> JavaDoc
	/jar 	---> Binary File

Installing:
-----------
	* Extract the jCalculus.tar or jhd.zip to any of the location say C:\
	
Running:
-------
	* java -cp "jdh.jar" jdh.Main